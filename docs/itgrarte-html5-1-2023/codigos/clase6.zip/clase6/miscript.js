var miBoton = document.getElementById('elboton');

miBoton.addEventListener('click', function() {
    alert('¡Hola, espero te encuentes muy bien!')
  })